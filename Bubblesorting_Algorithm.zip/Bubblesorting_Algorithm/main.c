#include <stdio.h>
#include <stdlib.h>

void bubbleSort1(int a[], int length); //ascending order
void bubbleSort2(int a[], int length); //descending order
int main()
{
    int b[] = {9,1,3,4,0,2,5,6};
    int size = 8;
    bubbleSort1(b,size);
    printf("Welcome to Mpho's Bubblesorting Algorithm\n");
    printf("Sorting in ascending order\n");
    for(int k = 0; k < size; k++){
        printf("b[%d] = %d\n", k, b[k]);
    }
    printf("\n");
    bubbleSort2(b,size);
    printf("Sorting in descending order\n");
    for(int k = 0; k < size; k++){
        printf("b[%d] = %d\n", k, b[k]);
    }
    getchar();
    return 0;
}
void bubbleSort1(int a[], int length){
    int temp;
    for (int i=0; i < length; i++){
        for(int j=0; j < (length - 1 - i); j++){
            if(a[j] > a[j+1]){
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
}
void bubbleSort2(int a[], int length){
    int temp;
    for (int i=0; i < length; i++){
        for(int j=0; j < (length - 1 - i); j++){
            if(a[j] < a[j+1]){
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
}

